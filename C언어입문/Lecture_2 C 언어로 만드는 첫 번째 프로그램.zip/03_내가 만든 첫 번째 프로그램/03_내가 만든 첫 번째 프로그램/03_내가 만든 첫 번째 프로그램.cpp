#include <stdio.h>

void main()
{
	printf("Hello~ world!!\n");
	printf("���ο�");
}